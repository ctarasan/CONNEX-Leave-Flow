
import { LeaveRequest, Notification, User, UserRole, LeaveStatus, LeaveType, AttendanceRecord } from './types';
import { HOLIDAYS_2026 } from './constants';

const STORAGE_KEYS = {
  LEAVE_REQUESTS: 'hr_leave_requests',
  NOTIFICATIONS: 'hr_notifications',
  CURRENT_USER: 'hr_current_user',
  USERS: 'hr_users_list',
  HOLIDAYS: 'hr_company_holidays',
  ATTENDANCE: 'hr_attendance_records',
};

const DEFAULT_QUOTAS: Record<LeaveType, number> = {
  [LeaveType.SICK]: 30,
  [LeaveType.VACATION]: 12,
  [LeaveType.PERSONAL]: 3,
  [LeaveType.MATERNITY]: 90,
  [LeaveType.STERILIZATION]: 999,
  [LeaveType.OTHER]: 0,
};

const INITIAL_USERS: User[] = [
  { id: '001', name: 'นายชำนาญ ธรสารสมบัติ', email: 'chamnan.t@b-connex.net', password: '001', role: UserRole.ADMIN, department: 'Management', joinDate: '2004-07-08', quotas: { ...DEFAULT_QUOTAS } },
  { id: '002', name: 'นายสารวุฒิ พิทักษ์เศวตไชย', email: 'sarawuth.p@b-connex.net', password: '002', role: UserRole.MANAGER, department: 'Management', joinDate: '2004-07-08', managerId: '001', quotas: { ...DEFAULT_QUOTAS } },
  { id: '003', name: 'นางพูลทรัพย์ ธรสารสมบัติ', email: 'poolsub.t@b-connex.net', password: '003', role: UserRole.EMPLOYEE, department: 'Finance', joinDate: '2004-07-08', managerId: '001', quotas: { ...DEFAULT_QUOTAS } },
  { id: '004', name: 'นางสาวศรีประไพ ศรีติมงคล', email: 'sriprapai.s@b-connex.net', password: '004', role: UserRole.EMPLOYEE, department: 'Operation', joinDate: '2012-11-01', managerId: '002', quotas: { ...DEFAULT_QUOTAS } },
  { id: '005', name: 'นายอนุมาศ ไชยชนะ', email: 'anumart.c@b-connex.net', password: '005', role: UserRole.EMPLOYEE, department: 'Operation', joinDate: '2014-05-02', managerId: '002', quotas: { ...DEFAULT_QUOTAS } },
];

export const getAllUsers = (): User[] => {
  const stored = localStorage.getItem(STORAGE_KEYS.USERS);
  if (!stored) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
    return INITIAL_USERS;
  }
  return JSON.parse(stored);
};

export const updateUser = (updatedUser: User) => {
  const users = getAllUsers();
  const updatedList = users.map(u => u.id === updatedUser.id ? updatedUser : u);
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updatedList));
  
  const current = getInitialUser();
  if (current && current.id === updatedUser.id) {
    saveCurrentUser(updatedUser);
  }
};

export const getInitialUser = (): User | null => {
  const stored = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  return stored ? JSON.parse(stored) : null;
};

export const saveCurrentUser = (user: User) => {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
};

export const logoutUser = () => {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
};

// Attendance
export const getAttendanceRecords = (userId?: string): AttendanceRecord[] => {
  const stored = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
  const records: AttendanceRecord[] = stored ? JSON.parse(stored) : [];
  return userId ? records.filter(r => r.userId === userId) : records;
};

export const saveAttendance = (userId: string, type: 'IN' | 'OUT'): AttendanceRecord => {
  const records = getAttendanceRecords();
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  const timeStr = now.toLocaleTimeString('th-TH', { hour12: false });
  
  let record = records.find(r => r.userId === userId && r.date === dateStr);
  const users = getAllUsers();
  const user = users.find(u => u.id === userId);

  if (!record) {
    const isLate = type === 'IN' && timeStr > "09:30:00";
    record = {
      id: Math.random().toString(36).substr(2, 9),
      userId,
      date: dateStr,
      checkIn: type === 'IN' ? timeStr : undefined,
      checkOut: type === 'OUT' ? timeStr : undefined,
      isLate,
      penaltyApplied: false
    };

    if (isLate && user) {
      user.quotas.VACATION = Math.max(0, user.quotas.VACATION - 0.25);
      updateUser(user);
      record.penaltyApplied = true;
      
      createNotification({
        userId,
        title: 'แจ้งเตือนการเข้างานสาย',
        message: `คุณเข้างานเวลา ${timeStr} ซึ่งเกินกำหนด 09:30 น. ระบบได้หักโควต้าลาพักร้อน 0.25 วันอัตโนมัติ`,
      });

      // Notify Manager
      if (user.managerId) {
        createNotification({
          userId: user.managerId,
          title: 'แจ้งเตือนพนักงานเข้าสาย',
          message: `${user.name} เข้างานสายเมื่อเวลา ${timeStr} (หักโควต้า 0.25 วัน)`,
        });
      }
    }
    
    records.unshift(record);
  } else {
    if (type === 'IN' && !record.checkIn) {
      record.checkIn = timeStr;
      record.isLate = timeStr > "09:30:00";
      if (record.isLate && !record.penaltyApplied && user) {
         user.quotas.VACATION = Math.max(0, user.quotas.VACATION - 0.25);
         updateUser(user);
         record.penaltyApplied = true;
         createNotification({
            userId,
            title: 'แจ้งเตือนการเข้างานสาย',
            message: `คุณเข้างานเวลา ${timeStr} ซึ่งเกินกำหนด 09:30 น. ระบบได้หักโควต้าลาพักร้อน 0.25 วันอัตโนมัติ`,
          });
          
          if (user.managerId) {
            createNotification({
              userId: user.managerId,
              title: 'แจ้งเตือนพนักงานเข้าสาย',
              message: `${user.name} เข้างานสายเมื่อเวลา ${timeStr} (หักโควต้า 0.25 วัน)`,
            });
          }
      }
    } else if (type === 'OUT') {
      record.checkOut = timeStr;
    }
  }

  localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(records));
  return record;
};

// Leave Requests
export const getLeaveRequests = (): LeaveRequest[] => {
  const stored = localStorage.getItem(STORAGE_KEYS.LEAVE_REQUESTS);
  return stored ? JSON.parse(stored) : [];
};

export const saveLeaveRequest = (data: Omit<LeaveRequest, 'id' | 'status' | 'submittedAt'>) => {
  const requests = getLeaveRequests();
  const newRequest: LeaveRequest = {
    ...data,
    id: Math.random().toString(36).substr(2, 9),
    status: LeaveStatus.PENDING,
    submittedAt: new Date().toISOString(),
  };
  
  const updated = [newRequest, ...requests];
  localStorage.setItem(STORAGE_KEYS.LEAVE_REQUESTS, JSON.stringify(updated));

  const users = getAllUsers();
  const employee = users.find(u => u.id === data.userId);
  if (employee?.managerId) {
    createNotification({
      userId: employee.managerId,
      title: 'คำขอลาใหม่จากพนักงาน',
      message: `${data.userName} ได้ส่งคำขอลาประเภท ${data.type} ตั้งแต่วันที่ ${data.startDate}`,
    });
  }
};

export const updateRequestStatus = (id: string, status: LeaveStatus, managerComment: string, managerId: string) => {
  const requests = getLeaveRequests();
  const request = requests.find(r => r.id === id);
  if (!request) return;

  const updated = requests.map(r => 
    r.id === id ? { ...r, status, managerComment, reviewedAt: new Date().toISOString() } : r
  );
  localStorage.setItem(STORAGE_KEYS.LEAVE_REQUESTS, JSON.stringify(updated));

  createNotification({
    userId: request.userId,
    title: status === LeaveStatus.APPROVED ? 'คำขอลาได้รับการอนุมัติ' : 'คำขอลาถูกปฏิเสธ',
    message: `คำขอลาช่วงวันที่ ${request.startDate} ของคุณได้รับการพิจารณาแล้ว: ${status === LeaveStatus.APPROVED ? 'อนุมัติ' : 'ไม็นุมัติ'}`,
  });
};

// Notifications
export const getNotifications = (userId: string): Notification[] => {
  const stored = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
  const allNotifs: Notification[] = stored ? JSON.parse(stored) : [];
  return allNotifs.filter(n => n.userId === userId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

const createNotification = (data: Omit<Notification, 'id' | 'isRead' | 'createdAt'>) => {
  const stored = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
  const allNotifs: Notification[] = stored ? JSON.parse(stored) : [];
  const newNotif: Notification = {
    ...data,
    id: Math.random().toString(36).substr(2, 9),
    isRead: false,
    createdAt: new Date().toISOString(),
  };
  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([newNotif, ...allNotifs]));
};

export const markNotifAsRead = (id: string) => {
  const stored = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
  const allNotifs: Notification[] = stored ? JSON.parse(stored) : [];
  const updated = allNotifs.map(n => n.id === id ? { ...n, isRead: true } : n);
  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
};

// Holidays
export const getHolidays = (): Record<string, string> => {
  const stored = localStorage.getItem(STORAGE_KEYS.HOLIDAYS);
  if (!stored) {
    localStorage.setItem(STORAGE_KEYS.HOLIDAYS, JSON.stringify(HOLIDAYS_2026));
    return HOLIDAYS_2026;
  }
  return JSON.parse(stored);
};

export const saveHoliday = (date: string, name: string) => {
  const current = getHolidays();
  current[date] = name;
  localStorage.setItem(STORAGE_KEYS.HOLIDAYS, JSON.stringify(current));
};

export const deleteHoliday = (date: string) => {
  const current = getHolidays();
  delete current[date];
  localStorage.setItem(STORAGE_KEYS.HOLIDAYS, JSON.stringify(current));
};
