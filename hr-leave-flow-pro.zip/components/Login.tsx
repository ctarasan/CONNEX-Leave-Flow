
import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { getAllUsers, saveCurrentUser } from '../store';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isError, setIsError] = useState(false);
  
  const users = getAllUsers();

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const foundUser = users.find(u => u.email === email && u.password === password);
    
    if (foundUser) {
      saveCurrentUser(foundUser);
      onLogin(foundUser);
    } else {
      setIsError(true);
      setTimeout(() => setIsError(false), 3000);
    }
  };

  const handleDemoClick = (user: User) => {
    setEmail(user.email);
    setPassword(user.password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-600 rounded-2xl text-white text-4xl font-bold shadow-xl mb-4">
            L
          </div>
          <h1 className="text-3xl font-extrabold text-gray-900">HR Leave Flow</h1>
          <p className="mt-2 text-gray-600">ลงชื่อเข้าใช้งานเพื่อเริ่มทำรายการ</p>
        </div>

        <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
          <form onSubmit={handleLoginSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Email Address</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@b-connex.net"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition text-sm"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="รหัสผ่าน (ID พนักงาน)"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition text-sm"
                required
              />
            </div>

            {isError && (
              <p className="text-red-500 text-xs text-center font-semibold">อีเมลหรือรหัสผ่านไม่ถูกต้อง</p>
            )}

            <button 
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition transform hover:-translate-y-0.5 active:translate-y-0 shadow-lg shadow-blue-200"
            >
              เข้าสู่ระบบ
            </button>
          </form>

          <div className="mt-8">
            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="px-3 bg-white text-gray-400 font-bold uppercase tracking-wider">Demo Access</span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-2 max-h-[250px] overflow-y-auto pr-2 custom-scrollbar">
              {users.slice(0, 5).map(user => (
                <button
                  key={user.id}
                  onClick={() => handleDemoClick(user)}
                  className="flex items-center justify-between px-3 py-2 bg-gray-50 border border-gray-100 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition text-left group"
                >
                  <div className="flex flex-col">
                    <p className="text-xs font-bold text-gray-800 group-hover:text-blue-700">{user.name}</p>
                    <p className="text-[10px] text-gray-500">{user.role}</p>
                  </div>
                  <span className="text-[10px] bg-gray-200 px-1.5 py-0.5 rounded font-mono">PW: {user.password}</span>
                </button>
              ))}
              <p className="text-[10px] text-center text-gray-400 italic">เลือกบัญชีตัวอย่างเพื่อทดสอบระบบ</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
