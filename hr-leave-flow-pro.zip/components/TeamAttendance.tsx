
import React, { useMemo } from 'react';
import { User, AttendanceRecord, UserRole } from '../types';
import { getAttendanceRecords, getAllUsers } from '../store';

interface TeamAttendanceProps {
  manager: User;
}

const TeamAttendance: React.FC<TeamAttendanceProps> = ({ manager }) => {
  const allUsers = useMemo(() => getAllUsers(), []);
  const subordinates = useMemo(() => {
    if (manager.role === UserRole.ADMIN) return allUsers;
    return allUsers.filter(u => u.managerId === manager.id);
  }, [allUsers, manager]);

  const teamRecords = useMemo(() => {
    const allAttendance = getAttendanceRecords();
    const subIds = subordinates.map(s => s.id);
    return allAttendance
      .filter(r => subIds.includes(r.userId))
      .map(r => ({
        ...r,
        userName: subordinates.find(s => s.id === r.userId)?.name || 'Unknown',
        department: subordinates.find(s => s.id === r.userId)?.department || '-'
      }))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [subordinates]);

  return (
    <div className="bg-white rounded-[32px] shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6 border-b border-gray-100 flex justify-between items-center">
        <h3 className="text-lg font-black text-gray-900">การเข้างานของทีม</h3>
        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-rose-500"></div>
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">มาสาย</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">ปกติ</span>
          </div>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">พนักงาน</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">วันที่</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">เวลาเข้า (IN)</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">เวลาออก (OUT)</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">สถานะ</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {teamRecords.map(rec => (
              <tr key={rec.id} className="hover:bg-gray-50 transition">
                <td className="px-6 py-4">
                  <div className="font-black text-gray-900 text-sm">{rec.userName}</div>
                  <div className="text-[10px] text-gray-400 font-bold uppercase">{rec.department}</div>
                </td>
                <td className="px-6 py-4 text-center font-bold text-gray-700 text-sm">
                  {new Date(rec.date).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
                </td>
                <td className={`px-6 py-4 text-center font-black text-sm ${rec.isLate ? 'text-rose-600' : 'text-emerald-600'}`}>
                  {rec.checkIn || '-'}
                </td>
                <td className="px-6 py-4 text-center font-bold text-gray-900 text-sm">
                  {rec.checkOut || '-'}
                </td>
                <td className="px-6 py-4 text-right">
                  {rec.isLate ? (
                    <div className="flex flex-col items-end">
                      <span className="bg-rose-100 text-rose-700 px-2 py-1 rounded-lg text-[10px] font-black uppercase">มาสาย</span>
                      <span className="text-[9px] text-rose-400 font-bold mt-1 tracking-tighter">หักพักร้อน 0.25 วัน</span>
                    </div>
                  ) : (
                    <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-lg text-[10px] font-black uppercase">ปกติ</span>
                  )}
                </td>
              </tr>
            ))}
            {teamRecords.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-20 text-center text-gray-400 font-bold italic">ไม่พบประวัติการเข้างานของพนักงานในทีม</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TeamAttendance;
