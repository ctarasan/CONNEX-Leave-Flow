
import React, { useEffect, useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from 'recharts';
import { LeaveRequest, LeaveType, User } from '../types';
import { LEAVE_TYPE_LABELS } from '../constants';
import { generateMonthlySummary } from '../services/geminiService';
import { getAllUsers } from '../store';

interface ReportSummaryProps {
  requests: LeaveRequest[];
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

const ReportSummary: React.FC<ReportSummaryProps> = ({ requests }) => {
  const [aiSummary, setAiSummary] = useState<string>('');
  const [loadingAi, setLoadingAi] = useState(false);
  const [selectedUser, setSelectedUser] = useState<string>('all');
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    setUsers(getAllUsers());
  }, []);

  const filteredRequests = useMemo(() => {
    if (selectedUser === 'all') return requests;
    return requests.filter(r => r.userId === selectedUser);
  }, [requests, selectedUser]);

  // Calculate stats for Charts
  const stats = useMemo(() => Object.values(LeaveType).map(type => ({
    name: LEAVE_TYPE_LABELS[type],
    count: filteredRequests.filter(r => r.type === type).length,
  })).filter(s => s.count > 0), [filteredRequests]);

  const handleGenAiSummary = async () => {
    setLoadingAi(true);
    const userName = selectedUser === 'all' ? 'พนักงานทุกคน' : (users.find(u => u.id === selectedUser)?.name || 'พนักงาน');
    const summary = await generateMonthlySummary(filteredRequests, `สรุปข้อมูลการลาของ ${userName}`);
    setAiSummary(summary);
    setLoadingAi(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
          <div>
            <h2 className="text-2xl font-black text-gray-900">สรุปรายงานการลา</h2>
            <p className="text-sm text-gray-500 font-medium mt-1">วิเคราะห์สถิติและพฤติกรรมการลาด้วย AI รายเดือน</p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-gray-50 p-3 rounded-3xl border border-gray-100 w-full md:w-auto">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">เลือกพนักงาน:</span>
            <select 
              value={selectedUser}
              onChange={(e) => {
                setSelectedUser(e.target.value);
                setAiSummary(''); // Clear AI summary when changing user
              }}
              className="bg-white border-2 border-gray-100 rounded-2xl px-4 py-2 text-sm font-bold text-gray-700 focus:border-blue-500 outline-none transition w-full sm:w-64"
            >
              <option value="all">พนักงานทุกคนในสังกัด</option>
              {users.map(u => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
            </select>
          </div>
        </div>

        {filteredRequests.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
            <div className="h-[350px] w-full">
              <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-6 text-center">การกระจายตัวประเภทการลา</p>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="count"
                  >
                    {stats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="h-[350px] w-full">
              <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-6 text-center">สถิติการลาแยกตามประเภท (จำนวนครั้ง)</p>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700 }} />
                  <Tooltip 
                    cursor={{ fill: '#f9fafb' }}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="count" radius={[10, 10, 0, 0]}>
                    {stats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        ) : (
          <div className="py-20 text-center bg-gray-50 rounded-[32px] border-2 border-dashed border-gray-100 mb-12">
            <p className="text-gray-400 font-bold italic">ไม่พบข้อมูลการลาของพนักงานในช่วงที่เลือก</p>
          </div>
        )}

        <div className="bg-blue-600 rounded-[32px] p-8 text-white shadow-xl shadow-blue-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-32 translate-x-32 blur-3xl"></div>
          <div className="relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-black">AI Analysis Insight</h3>
                  <p className="text-blue-100 text-sm font-medium">ประมวลผลสรุปด้วย Gemini AI สำหรับผู้บริหาร</p>
                </div>
              </div>
              
              <button 
                onClick={handleGenAiSummary}
                disabled={loadingAi || filteredRequests.length === 0}
                className="bg-white text-blue-600 px-8 py-4 rounded-2xl font-black text-sm hover:bg-blue-50 transition shadow-lg active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loadingAi ? 'กำลังวิเคราะห์...' : 'เริ่มการวิเคราะห์ด้วย AI'}
              </button>
            </div>

            {aiSummary && (
              <div className="mt-8 p-6 bg-white/10 rounded-[24px] backdrop-blur-md border border-white/10 animate-in slide-in-from-bottom-4 duration-500">
                <div className="prose prose-invert max-w-none">
                  <p className="text-white leading-relaxed whitespace-pre-wrap font-medium">
                    {aiSummary}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
        <h3 className="text-lg font-black text-gray-900 mb-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
            </svg>
          </div>
          รายการประวัติที่ใช้ในการวิเคราะห์
        </h3>
        
        <div className="overflow-x-auto rounded-3xl border border-gray-50">
          <table className="w-full text-left">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">พนักงาน</th>
                <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">ประเภท</th>
                <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">ระยะเวลา</th>
                <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">เหตุผล</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredRequests.map(r => (
                <tr key={r.id} className="hover:bg-gray-50 transition">
                  <td className="px-6 py-4">
                    <p className="text-sm font-black text-gray-900">{r.userName}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md">
                      {LEAVE_TYPE_LABELS[r.type]}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-[10px] font-bold text-gray-700">{r.startDate} ถึง {r.endDate}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-xs text-gray-500 italic truncate max-w-xs">{r.reason}</p>
                  </td>
                </tr>
              ))}
              {filteredRequests.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-10 text-center text-gray-400 italic text-sm">ไม่พบข้อมูลประวัติการลา</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ReportSummary;
