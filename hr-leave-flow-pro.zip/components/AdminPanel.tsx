
import React, { useState, useEffect } from 'react';
import { User, LeaveType } from '../types';
import { getAllUsers, updateUser, getHolidays, saveHoliday, deleteHoliday } from '../store';
import { LEAVE_TYPE_LABELS } from '../constants';
import DatePicker from './DatePicker';

const AdminPanel: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'employees' | 'holidays'>('employees');
  const [users, setUsers] = useState<User[]>([]);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  // Holiday State
  const [holidays, setHolidays] = useState<Record<string, string>>({});
  const [newHolidayDate, setNewHolidayDate] = useState('');
  const [newHolidayName, setNewHolidayName] = useState('');

  useEffect(() => {
    setUsers(getAllUsers());
    setHolidays(getHolidays());
  }, []);

  const handleEdit = (user: User) => {
    setEditingUser({ ...user, quotas: { ...user.quotas } });
  };

  const handleSave = () => {
    if (editingUser) {
      updateUser(editingUser);
      setUsers(getAllUsers());
      setEditingUser(null);
      alert('บันทึกข้อมูลพนักงานเรียบร้อยแล้ว');
    }
  };

  const handleQuotaChange = (type: LeaveType, value: string) => {
    if (editingUser) {
      const numValue = parseInt(value) || 0;
      setEditingUser({
        ...editingUser,
        quotas: {
          ...editingUser.quotas,
          [type]: numValue
        }
      });
    }
  };

  const handleAddHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHolidayDate || !newHolidayName) return;
    saveHoliday(newHolidayDate, newHolidayName);
    setHolidays(getHolidays());
    setNewHolidayDate('');
    setNewHolidayName('');
  };

  const handleDeleteHoliday = (date: string) => {
    if (window.confirm(`ต้องการลบวันหยุดวันที่ ${date} หรือไม่?`)) {
      deleteHoliday(date);
      setHolidays(getHolidays());
    }
  };

  const sortedHolidayDates = Object.keys(holidays).sort();

  return (
    <div className="space-y-6">
      <div className="flex gap-2 p-1 bg-gray-100 rounded-xl w-fit">
        <button 
          onClick={() => setActiveSubTab('employees')}
          className={`px-4 py-2 rounded-lg text-xs font-black transition ${activeSubTab === 'employees' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
        >
          รายชื่อพนักงาน
        </button>
        <button 
          onClick={() => setActiveSubTab('holidays')}
          className={`px-4 py-2 rounded-lg text-xs font-black transition ${activeSubTab === 'holidays' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
        >
          จัดการวันหยุดบริษัท
        </button>
      </div>

      {activeSubTab === 'employees' ? (
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-200">
          <h2 className="text-xl font-bold mb-6 text-gray-900 flex items-center gap-2">
            <div className="w-10 h-10 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
            </div>
            รายชื่อและสิทธิพนักงาน
          </h2>
          
          <div className="overflow-x-auto rounded-xl border border-gray-100">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-left">
                  <th className="px-6 py-4 font-black text-gray-400 uppercase text-[10px] tracking-widest">พนักงาน</th>
                  <th className="px-6 py-4 font-black text-gray-400 uppercase text-[10px] tracking-widest">แผนก</th>
                  <th className="px-6 py-4 font-black text-gray-400 uppercase text-[10px] tracking-widest text-center">ลาพักร้อน</th>
                  <th className="px-6 py-4 font-black text-gray-400 uppercase text-[10px] tracking-widest text-right">การจัดการ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {users.map(user => (
                  <tr key={user.id} className="hover:bg-gray-50 transition group">
                    <td className="px-6 py-4">
                      <div className="font-black text-gray-900">{user.name}</div>
                      <div className="text-[10px] text-gray-400 font-bold">{user.email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-gray-100 px-2 py-1 rounded text-[10px] font-bold text-gray-600 uppercase">{user.department}</span>
                    </td>
                    <td className="px-6 py-4 text-center font-black text-blue-600">
                      {user.quotas[LeaveType.VACATION]} วัน
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => handleEdit(user)}
                        className="text-xs font-black text-blue-600 hover:text-blue-800 uppercase tracking-tighter"
                      >
                        แก้ไขสิทธิ
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <form onSubmit={handleAddHoliday} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-200">
              <h3 className="font-black text-gray-900 mb-6 flex items-center gap-2">
                <div className="w-8 h-8 bg-rose-100 rounded-xl flex items-center justify-center text-rose-600">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                </div>
                เพิ่มวันหยุด
              </h3>
              <div className="space-y-6">
                <DatePicker 
                  label="วันที่"
                  value={newHolidayDate}
                  onChange={setNewHolidayDate}
                  placeholder="เลือกวันหยุด"
                />
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase mb-2 tracking-widest">ชื่อวันหยุด</label>
                  <input 
                    type="text" 
                    required
                    placeholder="เช่น วันสงกรานต์"
                    value={newHolidayName}
                    onChange={(e) => setNewHolidayName(e.target.value)}
                    className="w-full p-4 bg-white border-2 border-gray-200 rounded-2xl outline-none focus:border-blue-500 font-bold text-sm transition"
                  />
                </div>
                <button type="submit" className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-sm hover:bg-blue-700 transition shadow-xl shadow-blue-50">
                  บันทึกวันหยุด
                </button>
              </div>
            </form>
          </div>
          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left font-black text-gray-400 uppercase text-[10px] tracking-widest">วันที่</th>
                    <th className="px-6 py-4 text-left font-black text-gray-400 uppercase text-[10px] tracking-widest">วันหยุด</th>
                    <th className="px-6 py-4 text-right"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {sortedHolidayDates.map(date => (
                    <tr key={date} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4 font-bold text-gray-700">
                        {new Date(date).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </td>
                      <td className="px-6 py-4 font-bold text-gray-900">{holidays[date]}</td>
                      <td className="px-6 py-4 text-right">
                        <button onClick={() => handleDeleteHoliday(date)} className="text-rose-400 hover:text-rose-600 p-2 rounded-lg hover:bg-rose-50 transition">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                  {sortedHolidayDates.length === 0 && (
                    <tr>
                      <td colSpan={3} className="px-6 py-12 text-center text-gray-400 font-bold italic">ไม่พบข้อมูลวันหยุด</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-[32px] p-8 max-w-lg w-full shadow-2xl border border-gray-100">
            <h3 className="text-xl font-black text-gray-900 mb-6 flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
              </div>
              แก้ไขสิทธิการลา: {editingUser.name}
            </h3>
            <div className="grid grid-cols-2 gap-4 mb-8">
              {Object.entries(LEAVE_TYPE_LABELS).map(([type, label]) => {
                if (type === LeaveType.OTHER) return null;
                return (
                  <div key={type}>
                    <label className="block text-[10px] font-black text-gray-400 uppercase mb-2 tracking-widest">{label} (วัน/ปี)</label>
                    <input 
                      type="number" 
                      value={editingUser.quotas[type as LeaveType] || 0}
                      onChange={(e) => handleQuotaChange(type as LeaveType, e.target.value)}
                      className="w-full p-4 bg-gray-50 border-2 border-transparent focus:border-blue-500 rounded-2xl outline-none font-bold text-sm transition"
                    />
                  </div>
                );
              })}
            </div>
            <div className="flex gap-4">
              <button 
                onClick={handleSave}
                className="flex-1 bg-blue-600 text-white py-4 rounded-2xl font-black hover:bg-blue-700 transition shadow-xl shadow-blue-50"
              >
                บันทึกการเปลี่ยนแปลง
              </button>
              <button 
                onClick={() => setEditingUser(null)}
                className="flex-1 bg-gray-100 text-gray-500 py-4 rounded-2xl font-black hover:bg-gray-200 transition"
              >
                ยกเลิก
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
