
import React, { useState, useMemo, useEffect } from 'react';
import { User, LeaveType, LeaveStatus } from '../types';
import { LEAVE_TYPE_LABELS, HOLIDAYS_2026 } from '../constants';
import { saveLeaveRequest, getLeaveRequests } from '../store';
import DatePicker from './DatePicker';

interface LeaveFormProps {
  user: User;
  onSuccess: () => void;
}

const LeaveForm: React.FC<LeaveFormProps> = ({ user, onSuccess }) => {
  const [type, setType] = useState<LeaveType>(LeaveType.VACATION);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [usage, setUsage] = useState<Record<LeaveType, number>>({
    [LeaveType.SICK]: 0,
    [LeaveType.VACATION]: 0,
    [LeaveType.PERSONAL]: 0,
    [LeaveType.MATERNITY]: 0,
    [LeaveType.STERILIZATION]: 0,
    [LeaveType.OTHER]: 0,
  });

  const calculateBusinessDays = (startStr: string, endStr: string) => {
    if (!startStr || !endStr) return 0;
    const start = new Date(startStr);
    const end = new Date(endStr);
    if (start > end) return 0;

    let count = 0;
    const curDate = new Date(start.getTime());
    while (curDate <= end) {
      const dayOfWeek = curDate.getDay();
      const isoDate = curDate.toISOString().split('T')[0];
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const isHoliday = !!HOLIDAYS_2026[isoDate];
      
      if (!isWeekend && !isHoliday) {
        count++;
      }
      curDate.setDate(curDate.getDate() + 1);
    }
    return count;
  };

  const requestedDays = useMemo(() => calculateBusinessDays(startDate, endDate), [startDate, endDate]);

  useEffect(() => {
    const allRequests = getLeaveRequests();
    const userRequests = allRequests.filter(r => r.userId === user.id && r.status !== LeaveStatus.REJECTED);
    
    const currentYear = new Date().getFullYear();
    const counts: any = {};
    Object.values(LeaveType).forEach(t => counts[t] = 0);

    userRequests.forEach(req => {
      const start = new Date(req.startDate);
      if (start.getFullYear() === currentYear) {
        counts[req.type] += calculateBusinessDays(req.startDate, req.endDate);
      }
    });
    setUsage(counts);
  }, [user.id]);

  const tenureYears = useMemo(() => {
    const joinDate = new Date(user.joinDate);
    const today = new Date();
    return (today.getTime() - joinDate.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
  }, [user.joinDate]);

  const validationMessage = useMemo(() => {
    if (!startDate) return null;
    const startObj = new Date(startDate);
    
    const dayOfWeek = startObj.getDay();
    const isoDate = startObj.toISOString().split('T')[0];
    if (dayOfWeek === 0 || dayOfWeek === 6) return 'วันที่เริ่มลาเป็นวันหยุดสุดสัปดาห์';
    if (HOLIDAYS_2026[isoDate]) return `วันที่เริ่มลาเป็นวันหยุดนักขัตฤกษ์ (${HOLIDAYS_2026[isoDate]})`;

    if (type === LeaveType.VACATION && tenureYears < 1) {
      return 'สิทธิลาพักร้อนจะใช้ได้เมื่ออายุงานครบ 1 ปีขึ้นไป';
    }

    if (endDate) {
      if (new Date(startDate) > new Date(endDate)) return 'วันที่เริ่มต้องไม่เกินวันที่สิ้นสุด';
      if (requestedDays === 0) return 'ช่วงเวลาที่เลือกไม่มีวันทำงาน (เป็นวันหยุดทั้งหมด)';

      const currentUsage = usage[type] || 0;
      const quota = user.quotas[type] || 0;

      if (quota > 0 && (currentUsage + requestedDays) > quota && type !== LeaveType.STERILIZATION) {
        return `สิทธิการลาประเภทนี้คงเหลือไม่เพียงพอ (ใช้ไปแล้ว ${currentUsage}/${quota} วัน)`;
      }
    }
    return null;
  }, [startDate, endDate, type, usage, tenureYears, user.quotas, requestedDays]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validationMessage || !startDate || !endDate || !reason) return;

    setLoading(true);
    saveLeaveRequest({
      userId: user.id,
      userName: user.name,
      type,
      startDate,
      endDate,
      reason,
    });

    setTimeout(() => {
      setLoading(false);
      onSuccess();
      setStartDate('');
      setEndDate('');
      setReason('');
      alert(`ส่งใบลาเรียบร้อยแล้ว (จำนวน ${requestedDays} วันทำการ)`);
    }, 500);
  };

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-200">
      <h2 className="text-xl font-black text-gray-900 mb-6 flex items-center gap-2">
        <div className="w-10 h-10 bg-blue-100 rounded-2xl flex items-center justify-center">
          <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
        </div>
        ส่งใบขอลาหยุด
      </h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-[10px] font-black text-gray-400 uppercase mb-2 tracking-widest">ประเภทการลา</label>
          <select 
            value={type} 
            onChange={(e) => setType(e.target.value as LeaveType)}
            className="w-full p-4 bg-white border-2 border-gray-200 rounded-2xl focus:border-blue-500 outline-none transition text-sm font-bold text-gray-800"
          >
            {Object.entries(LEAVE_TYPE_LABELS).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <DatePicker 
            label="จากวันที่"
            value={startDate}
            onChange={setStartDate}
            minDate={new Date().toISOString().split('T')[0]}
            placeholder="เลือกวันที่เริ่มลา"
          />
          <DatePicker 
            label="ถึงวันที่"
            value={endDate}
            onChange={setEndDate}
            minDate={startDate || new Date().toISOString().split('T')[0]}
            placeholder="เลือกวันที่สิ้นสุด"
          />
        </div>

        {startDate && endDate && requestedDays > 0 && (
          <div className="bg-blue-50/50 p-4 rounded-2xl border border-blue-100 flex items-center justify-between">
            <span className="text-xs font-bold text-blue-800 uppercase tracking-widest">วันทำงานที่ใช้:</span>
            <span className="text-xl font-black text-blue-600">{requestedDays} วัน</span>
          </div>
        )}

        <div>
          <label className="block text-[10px] font-black text-gray-400 uppercase mb-2 tracking-widest">เหตุผลประกอบการลา</label>
          <textarea 
            required
            rows={3}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full p-4 bg-white border-2 border-gray-200 rounded-2xl focus:border-blue-500 outline-none transition text-sm font-bold text-gray-800 placeholder:text-gray-300"
            placeholder="โปรระบุรายละเอียด..."
          />
        </div>

        {validationMessage && (
          <div className="p-4 bg-rose-50 text-rose-800 text-xs rounded-2xl border border-rose-100 font-bold flex gap-3 items-center">
            <svg className="w-5 h-5 shrink-0 text-rose-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
            {validationMessage}
          </div>
        )}

        <button 
          type="submit" 
          disabled={loading || !!validationMessage || !startDate || !endDate}
          className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black hover:bg-blue-700 transition disabled:opacity-40 shadow-xl shadow-blue-100 active:scale-[0.98]"
        >
          {loading ? 'กำลังประมวลผล...' : 'ยืนยันการส่งใบลา'}
        </button>
      </form>
    </div>
  );
};

export default LeaveForm;
