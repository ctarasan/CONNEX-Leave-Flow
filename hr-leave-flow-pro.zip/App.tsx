
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { User, UserRole, LeaveRequest, Notification, LeaveType, LeaveStatus, AttendanceRecord } from './types';
import { getInitialUser, saveCurrentUser, logoutUser, getLeaveRequests, getNotifications, getAllUsers, getAttendanceRecords } from './store';
import LeaveForm from './components/LeaveForm';
import ApprovalBoard from './components/ApprovalBoard';
import NotificationCenter from './components/NotificationCenter';
import ReportSummary from './components/ReportSummary';
import AdminPanel from './components/AdminPanel';
import AttendanceModule from './components/AttendanceModule';
import TeamAttendance from './components/TeamAttendance';
import VacationLedger from './components/VacationLedger';
import Login from './components/Login';
import { STATUS_LABELS, STATUS_COLORS, LEAVE_TYPE_LABELS, HOLIDAYS_2026 } from './constants';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(getInitialUser());
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [attendanceHistory, setAttendanceHistory] = useState<AttendanceRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'attendance' | 'history' | 'report' | 'admin'>('dashboard');
  const [historySubTab, setHistorySubTab] = useState<'leave' | 'attendance' | 'vacation' | 'team'>('leave');

  const calculateBusinessDays = (startStr: string, endStr: string) => {
    if (!startStr || !endStr) return 0;
    const start = new Date(startStr);
    const end = new Date(endStr);
    if (start > end) return 0;

    let count = 0;
    const curDate = new Date(start.getTime());
    while (curDate <= end) {
      const dayOfWeek = curDate.getDay();
      const isoDate = curDate.toISOString().split('T')[0];
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const isHoliday = !!HOLIDAYS_2026[isoDate];
      if (!isWeekend && !isHoliday) count++;
      curDate.setDate(curDate.getDate() + 1);
    }
    return count;
  };

  const fetchData = useCallback(() => {
    const updatedUser = getInitialUser();
    if (updatedUser) setCurrentUser(updatedUser);
    
    if (!updatedUser) return;
    const allRequests = getLeaveRequests();
    const allNotifs = getNotifications(updatedUser.id);
    const allAttendance = getAttendanceRecords(updatedUser.id);
    
    if (updatedUser.role === UserRole.ADMIN) {
      setRequests(allRequests);
    } else if (updatedUser.role === UserRole.MANAGER) {
      setRequests(allRequests); 
    } else {
      setRequests(allRequests.filter(r => r.userId === updatedUser.id));
    }
    
    setNotifications(allNotifs);
    setAttendanceHistory(allAttendance);
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    logoutUser();
    setCurrentUser(null);
  };

  const leaveUsage = useMemo(() => {
    const usage: Record<string, number> = {};
    Object.values(LeaveType).forEach(t => usage[t] = 0);
    
    requests
      .filter(r => r.userId === currentUser?.id && r.status === LeaveStatus.APPROVED)
      .forEach(r => {
        usage[r.type] += calculateBusinessDays(r.startDate, r.endDate);
      });
    return usage;
  }, [requests, currentUser]);

  if (!currentUser) {
    return <Login onLogin={handleLogin} />;
  }

  const isManagerOrAdmin = currentUser.role === UserRole.MANAGER || currentUser.role === UserRole.ADMIN;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      <aside className="w-full md:w-64 bg-white border-r border-gray-200 flex-shrink-0">
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-blue-100">L</div>
            <h1 className="font-bold text-gray-900 tracking-tight">LeaveFlow <span className="text-blue-600">Pro</span></h1>
          </div>

          <nav className="space-y-1">
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition ${activeTab === 'dashboard' ? 'bg-blue-50 text-blue-700' : 'text-gray-500 hover:bg-gray-50'}`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>
              หน้าแรก
            </button>
            <button 
              onClick={() => setActiveTab('attendance')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition ${activeTab === 'attendance' ? 'bg-blue-50 text-blue-700' : 'text-gray-500 hover:bg-gray-50'}`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" /></svg>
              ลงเวลาทำงาน
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition ${activeTab === 'history' ? 'bg-blue-50 text-blue-700' : 'text-gray-500 hover:bg-gray-50'}`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              ประวัติรายการ
            </button>
            {isManagerOrAdmin && (
              <button 
                onClick={() => setActiveTab('report')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition ${activeTab === 'report' ? 'bg-blue-50 text-blue-700' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002 2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
                รายงานสรุป
              </button>
            )}
            {currentUser.role === UserRole.ADMIN && (
              <button 
                onClick={() => setActiveTab('admin')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition ${activeTab === 'admin' ? 'bg-blue-50 text-blue-700' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                ตั้งค่าระบบ
              </button>
            )}
          </nav>

          <div className="mt-auto pt-10">
            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
              <p className="text-[10px] text-gray-400 font-bold uppercase mb-2 tracking-widest">User Session</p>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xs">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="overflow-hidden">
                  <p className="text-xs font-bold text-gray-900 truncate">{currentUser.name}</p>
                  <p className="text-[10px] text-gray-500 font-bold uppercase">{currentUser.role}</p>
                </div>
              </div>
              <button 
                onClick={handleLogout}
                className="w-full mt-3 text-[10px] font-bold text-red-500 hover:text-red-700 text-left px-1"
              >
                ออกจากระบบ
              </button>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto p-6 md:p-10">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-black text-gray-900">
              {activeTab === 'dashboard' && 'แดชบอร์ด'}
              {activeTab === 'attendance' && 'ลงเวลาทำงาน'}
              {activeTab === 'history' && 'ประวัติรายการ'}
              {activeTab === 'report' && 'รายงานการลา'}
              {activeTab === 'admin' && 'จัดการระบบ'}
            </h2>
            <p className="text-sm text-gray-500 font-medium">ยินดีต้อนรับกลับมา, {currentUser.name}</p>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-gray-400 uppercase">วันนี้</p>
            <p className="text-sm font-black text-gray-800">{new Date().toLocaleDateString('th-TH', { dateStyle: 'long' })}</p>
          </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <div className="xl:col-span-2 space-y-8">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {Object.entries(LEAVE_TYPE_LABELS).map(([type, label]) => {
                  const quota = currentUser.quotas[type as LeaveType] || 0;
                  const used = leaveUsage[type] || 0;
                  const remaining = quota - used;
                  if (type === LeaveType.OTHER) return null;
                  
                  return (
                    <div key={type} className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition">
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">{label}</p>
                      <div className="flex items-baseline gap-1">
                        {/* Fix: Moved toFixed(2) after Math.max to ensure number operations happen first */}
                        <span className="text-2xl font-black text-gray-900">{quota >= 999 ? '∞' : Math.max(0, remaining).toFixed(2)}</span>
                        <span className="text-[10px] text-gray-500 font-bold">วันคงเหลือ</span>
                      </div>
                      <div className="mt-3 w-full bg-gray-100 h-1 rounded-full overflow-hidden">
                        <div 
                          className={`h-full ${remaining < 2 ? 'bg-red-500' : 'bg-blue-500'}`} 
                          style={{ width: quota >= 999 ? '0%' : `${Math.min(100, (used / quota) * 100)}%` }}
                        />
                      </div>
                      <p className="mt-2 text-[10px] text-gray-400 font-bold">ใช้ไปแล้ว {used.toFixed(2)} วันทำการ</p>
                    </div>
                  );
                })}
              </div>

              {isManagerOrAdmin && (
                <ApprovalBoard requests={requests} onUpdate={fetchData} />
              )}

              <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-black text-gray-900">รายการลาล่าสุด</h3>
                  <button onClick={() => setActiveTab('history')} className="text-xs font-bold text-blue-600 hover:underline">ดูทั้งหมด</button>
                </div>
                <div className="space-y-4">
                  {requests.filter(r => r.userId === currentUser.id).slice(0, 5).map(req => (
                    <div key={req.id} className="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-xl hover:border-gray-200 transition">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-xs ${STATUS_COLORS[req.status]}`}>
                          {LEAVE_TYPE_LABELS[req.type].charAt(2)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900">{LEAVE_TYPE_LABELS[req.type]}</p>
                          <p className="text-[10px] text-gray-500 font-bold uppercase">{req.startDate} ถึง {req.endDate}</p>
                        </div>
                      </div>
                      <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase ${STATUS_COLORS[req.status]}`}>
                        {STATUS_LABELS[req.status]}
                      </span>
                    </div>
                  ))}
                  {requests.filter(r => r.userId === currentUser.id).length === 0 && (
                     <p className="text-center py-4 text-gray-400 italic text-sm">ยังไม่มีรายการลา</p>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <LeaveForm user={currentUser} onSuccess={fetchData} />
              <NotificationCenter notifications={notifications} onUpdate={fetchData} />
            </div>
          </div>
        )}

        {activeTab === 'attendance' && <AttendanceModule user={currentUser} onUpdate={fetchData} />}

        {activeTab === 'history' && (
          <div className="space-y-6">
            <div className="flex flex-wrap gap-2 p-1 bg-gray-100 rounded-xl w-fit">
              <button 
                onClick={() => setHistorySubTab('leave')}
                className={`px-4 py-2 rounded-lg text-xs font-black transition ${historySubTab === 'leave' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                ประวัติการลา
              </button>
              <button 
                onClick={() => setHistorySubTab('attendance')}
                className={`px-4 py-2 rounded-lg text-xs font-black transition ${historySubTab === 'attendance' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                ประวัติการลงเวลา
              </button>
              <button 
                onClick={() => setHistorySubTab('vacation')}
                className={`px-4 py-2 rounded-lg text-xs font-black transition ${historySubTab === 'vacation' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                รายละเอียดการหักวันลา
              </button>
              {isManagerOrAdmin && (
                <button 
                  onClick={() => setHistorySubTab('team')}
                  className={`px-4 py-2 rounded-lg text-xs font-black transition ${historySubTab === 'team' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  การเข้างานของทีม
                </button>
              )}
            </div>

            {historySubTab === 'leave' && (
              <div className="bg-white rounded-[32px] border border-gray-200 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">ประเภท / วันที่</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">เหตุผล</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">สถานะ</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">ส่งเมื่อ</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {requests.filter(r => r.userId === currentUser.id).map(req => (
                        <tr key={req.id} className="hover:bg-gray-50 transition">
                          <td className="px-6 py-4">
                            <p className="text-sm font-black text-gray-900">{LEAVE_TYPE_LABELS[req.type]}</p>
                            <p className="text-[10px] text-gray-500 font-bold uppercase">{req.startDate} ถึง {req.endDate}</p>
                          </td>
                          <td className="px-6 py-4">
                            <p className="text-xs text-gray-700 font-medium truncate max-w-xs">{req.reason}</p>
                            {req.managerComment && (
                              <div className="mt-1 flex items-start gap-1">
                                <span className="text-[9px] font-black text-blue-600 uppercase">Manager Note:</span>
                                <span className="text-[9px] text-gray-500 italic">"{req.managerComment}"</span>
                              </div>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase ${STATUS_COLORS[req.status]}`}>
                              {STATUS_LABELS[req.status]}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right text-[10px] font-bold text-gray-400">
                            {new Date(req.submittedAt).toLocaleDateString('th-TH')}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {requests.filter(r => r.userId === currentUser.id).length === 0 && <div className="text-center py-20 text-gray-400 font-bold italic text-sm">ไม่พบรายการประวัติการลา</div>}
                </div>
              </div>
            )}

            {historySubTab === 'attendance' && (
              <div className="bg-white rounded-[32px] border border-gray-200 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">วันที่</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">เวลาเข้า (IN)</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">เวลาออก (OUT)</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">สถานะ</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {attendanceHistory.map(rec => (
                        <tr key={rec.id} className="hover:bg-gray-50 transition">
                          <td className="px-6 py-4">
                            <p className="text-sm font-black text-gray-900">
                              {new Date(rec.date).toLocaleDateString('th-TH', { day: 'numeric', month: 'long', year: 'numeric' })}
                            </p>
                          </td>
                          <td className={`px-6 py-4 text-center font-black text-sm ${rec.isLate ? 'text-rose-600' : 'text-emerald-600'}`}>
                            {rec.checkIn || '-'}
                          </td>
                          <td className="px-6 py-4 text-center font-bold text-gray-900 text-sm">
                            {rec.checkOut || '-'}
                          </td>
                          <td className="px-6 py-4 text-right">
                            {rec.isLate ? (
                              <div className="flex flex-col items-end">
                                <span className="bg-rose-100 text-rose-700 px-2 py-1 rounded-lg text-[10px] font-black uppercase">มาสาย</span>
                                <span className="text-[9px] text-rose-400 font-bold mt-1 tracking-tighter">หักพักร้อน 0.25 วัน</span>
                              </div>
                            ) : (
                              <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-lg text-[10px] font-black uppercase">ปกติ</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {attendanceHistory.length === 0 && <div className="text-center py-20 text-gray-400 font-bold italic text-sm">ไม่พบประวัติการลงเวลา</div>}
                </div>
              </div>
            )}

            {historySubTab === 'vacation' && (
              <VacationLedger user={currentUser} />
            )}

            {historySubTab === 'team' && isManagerOrAdmin && (
              <TeamAttendance manager={currentUser} />
            )}
          </div>
        )}

        {activeTab === 'report' && <ReportSummary requests={requests} />}
        {activeTab === 'admin' && <AdminPanel />}
      </main>
    </div>
  );
};

export default App;
