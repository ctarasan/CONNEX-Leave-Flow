
import { GoogleGenAI, Type } from "@google/genai";
import { LeaveRequest } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateMonthlySummary = async (requests: LeaveRequest[], month: string) => {
  const statsString = JSON.stringify(requests.map(r => ({
    user: r.userName,
    type: r.type,
    days: r.startDate + ' to ' + r.endDate,
    status: r.status,
    reason: r.reason
  })));

  const prompt = `
    Analyze the following leave requests for the month of ${month}.
    Provide a professional summary in Thai language for the manager.
    Focus on:
    1. Overall leave trends (which type is most common).
    2. Any potential red flags (multiple employees out at once).
    3. A brief "Manager's Advice" section.
    
    Data: ${statsString}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "ไม่สามารถดึงข้อมูลสรุปจาก AI ได้ในขณะนี้";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "เกิดข้อผิดพลาดในการประมวลผลสรุปด้วย AI";
  }
};
